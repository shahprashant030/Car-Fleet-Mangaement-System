
              google.charts.load('current', {'packages':['gauge']});
              google.charts.setOnLoadCallback(drawChart);
               var battery=40;
               
              function drawChart() {
        
                var data = google.visualization.arrayToDataTable([
                  ['Label', 'Value'],
                  ['Battery', 40]
                                   
                ]);
        
                var options = {
                  width: 1000, height: 200,
                  redFrom: 90, redTo: 100,
                  yellowFrom:75, yellowTo: 90,
                  minorTicks: 2
                };
        
                var chart = new google.visualization.Gauge(document.getElementById('chart_div1'));
        
                chart.draw(data, options);
        
                setInterval(function() {
                  data.setValue(0, 1, battery);
                  chart.draw(data, options);
                }, 1000);
                
               
          

              }
            
          
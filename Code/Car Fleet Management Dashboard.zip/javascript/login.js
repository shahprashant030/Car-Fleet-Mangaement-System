function loginUser(){
    var email=document.getElementById("u_email").value;
    var password=document.getElementById("u_password").value;

    firebase.auth().signInWithEmailAndPassword(email,password).then(
        function(){
            window.location="/html/index.html";
        }).catch(function(error){
        var errorMessage=error.errorMessage;
        alert(errorMessage);
    });
}
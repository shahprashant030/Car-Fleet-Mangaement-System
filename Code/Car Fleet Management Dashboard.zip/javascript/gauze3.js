<script src="https://www.gstatic.com/firebasejs/7.7.0/firebase-app.js"></script>

    <!-- If you enabled Analytics in your project, add the Firebase SDK for Analytics -->
    <script src="https://www.gstatic.com/firebasejs/7.7.0/firebase-analytics.js"></script>

    <!-- Add Firebase products that you want to use -->
    <script src="https://www.gstatic.com/firebasejs/7.7.0/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.7.0/firebase-database.js"></script>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

      google.charts.load('current', {
        'packages': ['gauge']
      });
      google.charts.setOnLoadCallback(drawChart);

      // Set the configuration for your app
      // TODO: Replace with your project's config object
      var config = {
        apiKey: "AIzaSyBuByyRr1B4dNXX2ayshv8RMRDrml-rmBo",
        authDomain: "green-house-aafcc.firebaseapp.com",
        databaseURL: "https://green-house-aafcc.firebaseio.com",
        storageBucket: "green-house-aafcc.appspot.com"
      };
      firebase.initializeApp(config);

      var temperature_value = 0;
      var moisture_value = 0;
      var humidity_value = 0;

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
          ['Temperature', temperature_value],
          ['Humidity', humidity_value],
          ['Mositure', moisture_value]
        ]);

        var options = {
          width: 400,
          height: 120,
          redFrom: 90,
          redTo: 100,
          yellowFrom: 75,
          yellowTo: 90,
          minorTicks: 5
        };

        var chart = new google.visualization.Gauge(document.getElementById('chart_div'));

        chart.draw(data, options);

        // setInterval(function () {
        //   data.setValue(0, 1, 40 + Math.round(60 * Math.random()));
        //   chart.draw(data, options);
        // }, 13000);
        // setInterval(function () {
        //   data.setValue(1, 1, 40 + Math.round(60 * Math.random()));
        //   chart.draw(data, options);
        // }, 5000);
        // setInterval(function () {
        //   data.setValue(2, 1, 60 + Math.round(20 * Math.random()));
        //   chart.draw(data, options);
        // }, 26000);



        // Get a reference to the database service
       

        var starCountRef = firebase.database().ref("/parameters");
        starCountRef.on('value', function (snapshot) {
          // updateStarCount(postElement, snapshot.val());

          temperature_value = snapshot.val().temperature;
          moisture_value = snapshot.val().moisture;
          humidity_value = snapshot.val().humidity;

          data.setValue(0, 1, temperature_value);
          data.setValue(1, 1, humidity_value);
          data.setValue(2, 1, moisture_value);

          chart.draw(data, options);
          console.log(snapshot.val())
        });

      }

      

var Config = {
    apiKey: "AIzaSyDAUwG0FDkjCt12MyfFzAL9rN3SAP7tiow",
    authDomain: "testangular-54267.firebaseapp.com",
    databaseURL: "https://testangular-54267.firebaseio.com",
    projectId: "testangular-54267",
    storageBucket: "testangular-54267.appspot.com",
    messagingSenderId: "946068558719",
    appId: "1:946068558719:web:ae5a838d1cb973caaac04a",
    measurementId: "G-HC50K57C58"
  };
  // Initialize Firebase
  firebase.initializeApp(Config);
  firebase.analytics();f

  var starCountRef = firebase.database().ref("parameters/");
    starCountRef.on('value', function (snapshot) {
      // updateStarCount(postElement, snapshot.val());
      
      battery = snapshot.val().battery;
      speed = snapshot.val().speed;
      latitude = snapshot.val().latitude;
      longitude = snapshot.val().longitude;
      
      alert(longitude);

      console.log(battery);
      
      battery = snapshot.val().battery;

    }); 



    var starCountRef = firebase.database().ref();
starCountRef.child('parameters').child('Motor_fan').on('value', function (snapshot) {

  document.getElementById("thisx").innerHTML = snapshot.val() ? "Fan ON" : "Fan OFF";
})

alert("in tryindexpage");
function on_off() {

    starCountRef.child('parameters').child('on_off').once('value', function (snapshot) {

      // document.getElementById("thisx").innerHTML = snapshot.val() ? "Fan OFF" : "Fan ON";

      starCountRef.child('parameters').child('on_off').set(!snapshot.val())
        .then(function () {

          console.log('Synchronization succeeded');
          // Return to index.html here...
        })
        .catch(function (error) {
          console.log('Synchronization failed');
        });
      console.log(snapshot.val())
    })


  }

  function wiper() {

    starCountRef.child('parameters').child('wiper').once('value', function (snapshot) {

      // document.getElementById("thisx").innerHTML = snapshot.val() ? "Fan OFF" : "Fan ON";

      starCountRef.child('parameters').child('wiper').set(!snapshot.val())
        .then(function () {

          console.log('Synchronization succeeded');
          // Return to index.html here...
        })
        .catch(function (error) {
          console.log('Synchronization failed');
        });
      console.log(snapshot.val())
    })


  }


